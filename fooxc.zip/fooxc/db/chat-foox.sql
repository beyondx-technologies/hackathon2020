-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 15, 2020 at 02:25 PM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 7.3.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `chat-foox`
--

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE `messages` (
  `id` int(11) NOT NULL,
  `u1` varchar(190) NOT NULL,
  `u2` varchar(190) NOT NULL,
  `msg` varchar(255) NOT NULL,
  `done` tinyint(1) NOT NULL,
  `tame` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `messages`
--

INSERT INTO `messages` (`id`, `u1`, `u2`, `msg`, `done`, `tame`) VALUES
(1, 'Sasi', 'Blind Ch3mistry', 'item1item2item3', 1, '2020-08-15 11:37:37'),
(2, 'Sasi', 'Blind Ch3mistry', 'item1<br>item2<br>', 1, '2020-08-15 08:01:52'),
(3, 'Sasi', 'Blind Ch3mistry', 'item3<br>', 1, '2020-08-15 11:37:37'),
(4, 'Sasi', 'Blind Ch3mistry', 'item3<br>', 1, '2020-08-15 08:01:56'),
(5, 'Sasi', 'Blind Ch3mistry', 'item2<br>item3<br>', 1, '2020-08-15 11:37:37'),
(6, 'Sasi', 'Blind Ch3mistry', 'item1<br>item3<br>', 1, '2020-08-15 11:37:37'),
(7, 'Sasi', 'Blind Ch3mistry', 'item3s<br>', 1, '2020-08-15 11:37:37'),
(8, 'Sasi', 'Blind Ch3mistry', 'item1<br>', 1, '2020-08-15 11:37:37'),
(9, 'Sasi', 'Blind Ch3mistry', 'item1<br>', 1, '2020-08-15 11:37:37'),
(10, 'Sasi', 'Blind Ch3mistry', 'item1<br>', 0, '2020-08-15 11:43:26'),
(11, 'Sasi', 'Blind Ch3mistry', 'item1<br>item2<br>', 0, '2020-08-15 11:43:52');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `messages`
--
ALTER TABLE `messages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
