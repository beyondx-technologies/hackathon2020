<?php
$db=mysqli_connect("localhost","root","","chat-foox");

if(isset($_GET['u2']))
{
    $msg=$_GET['u2'];
    $string1=mysqli_query($db,"select * from messages where u2='$msg' where done=0");
 $rows=array();
   while($row=mysqli_fetch_assoc($string1)){
        array_push($rows,$row);
//     //$rows[]=$row;
}
    //$rows=mysqli_fetch_all($string1);
    $josn=json_encode($rows);
    echo($josn);
}
if(isset($_POST['n']))
{
    $u1=$_POST['n'];
    mysqli_query($db,"update messages set done=1 where u1='$u1'");
}
?>