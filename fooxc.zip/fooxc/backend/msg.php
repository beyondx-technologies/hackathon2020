<?php
$db=mysqli_connect("localhost","root","","chat-foox");

if(isset($_POST['msg']))
{
    $msg=$_POST['msg'];
    mysqli_query($db,"insert into messages (u1,u2,msg,done) values ('Sasi','Blind Ch3mistry','$msg',0)");
   echo 1;
}
?>